echo "Fake uninstall a thing"
