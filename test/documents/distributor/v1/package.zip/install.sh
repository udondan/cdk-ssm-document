echo "Fake install a thing"
