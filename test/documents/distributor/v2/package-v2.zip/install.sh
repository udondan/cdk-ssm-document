echo "Fake install a thing v2"
