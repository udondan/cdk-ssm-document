echo "Fake uninstall a thing v2"
